#ifndef LIFE_H_INCLUDED
#define LIFE_H_INCLUDED


class Life
{
public:

    float moveLife = 0.0f;
    bool isCreateLife = false;
    float lifeX1=0.0625f,lifeX2=-0.0625f;
    float lifeMove=0.0f;


	void lifeBox();
	void bossLifeBox();
	void drawTextBox();
	void createLife();
	void drawLife(float x, float y);

};
#endif // LIFE_H_INCLUDED
