#ifndef OTHERSCENES_H_INCLUDED
#define OTHERSCENES_H_INCLUDED

class OtherScenes
{
public:

    bool isSoundOn = true;
	void gameIsOver();
	void victory();
};

#endif // OTHERSCENES_H_INCLUDED
