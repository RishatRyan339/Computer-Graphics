#ifndef OTHEROBJECTS_H_INCLUDED
#define OTHEROBJECTS_H_INCLUDED


class OtherObjects
{
public:

    float s1=0.0f,s2=0.0f;
    float moveXComet = 0.0f;
    float moveYComet = 0.0f;
    bool isBig = false;
	void createStar();
	void createComet();

};
#endif // OTHEROBJECTS_H_INCLUDED
