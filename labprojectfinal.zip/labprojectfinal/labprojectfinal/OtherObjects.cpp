#include <iostream>
#include <stdio.h>
#include<GL/gl.h>
#include <GL/glut.h>
#include <conio.h>
#include <windows.h>
#include "OtherObjects.h"
#include<GL/gl.h>
#include <windows.h>
#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif
#include<math.h>>
# define PI           3.14159265358979323846
#include <stdlib.h>


#define GRAVITY 10
#define PI 3.14159265
#include <time.h>
#include<stdio.h>


void OtherObjects::createStar()
{
    glScalef(s1,s2,0);
    glColor3d(1,1,1);
    glBegin(GL_POLYGON);
        glVertex3f(0.0f, 0.0f, 0.0f);
        glVertex3f(0.037f, 0.0f, 0.0f);
        glVertex3f(0.037f, 0.0428f, 0.0f);
        glVertex3f(0.0f, 0.0428f, 0.0f);
	glEnd();
    glBegin(GL_POLYGON);
        glVertex3f(0.0f, 0.0428f, 0.0f);
        glVertex3f(0.0185f, 0.3f, 0.0f);
        glVertex3f(0.037f, 0.0428f, 0.0f);
	glEnd();
    glBegin(GL_POLYGON);
        glVertex3f(0.0f, 0.0f, 0.0f);
        glVertex3f(0.0185f, -0.27f, 0.0f);
        glVertex3f(0.037f, 0.0f, 0.0f);
	glEnd();
    glBegin(GL_POLYGON);
        glVertex3f(0.0f, 0.0f, 0.0f);
        glVertex3f(0.0f, 0.0428f, 0.0f);
        glVertex3f(-0.2f, 0.0214f, 0.0f);
	glEnd();
    glBegin(GL_POLYGON);
        glVertex3f(0.037f, 0.0f, 0.0f);
        glVertex3f(0.037f, 0.0428f, 0.0f);
        glVertex3f(0.25f, 0.0214f, 0.0f);
	glEnd();
}
void OtherObjects::createComet()
{
    glTranslatef(moveXComet, moveYComet, 0.0f);
    glColor3d(1,.8,.2);
    glutWireSphere(.02,20,20);
    glLineWidth(2);
    glBegin(GL_LINES);
        glVertex3f(0.002f, -0.002f, 0.0f);
        glVertex3f(-0.175f, -0.2f, 0.0f);
    glEnd();
    glBegin(GL_LINES);
        glVertex3f(0.012f, 0.0f, 0.0f);
        glVertex3f(-0.13f, -0.18f, 0.0f);
    glEnd();
    glBegin(GL_LINES);
        glVertex3f(-0.01f, 0.0f, 0.0f);
        glVertex3f(-0.17f, -0.18f, 0.0f);
    glEnd();
    glBegin(GL_LINES);
        glVertex3f(-0.015f, 0.0f, 0.0f);
        glVertex3f(-0.17f, -0.17f, 0.0f);
    glEnd();
    glBegin(GL_LINES);
        glVertex3f(0.0f, -0.018f, 0.0f);
        glVertex3f(-0.12f, -0.2f, 0.0f);
    glEnd();
    glBegin(GL_LINES);
        glVertex3f(0.0f, 0.0f, 0.0f);
        glVertex3f(-0.15f, -0.2f, 0.0f);
    glEnd();
}

